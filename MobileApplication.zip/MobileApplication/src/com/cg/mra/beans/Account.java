package com.cg.mra.beans;

public class Account {
  private  String customerName;
  private  String accountType;
  private  int accountBalance;
  public Account(String customerName,String accountType,int accountBalance) {
	  this.customerName=customerName;
	  this.accountType=accountType;
	  this.accountBalance=accountBalance;
  }
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public int getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(int rechargeAmount) {
	this.accountBalance = rechargeAmount;
}

}