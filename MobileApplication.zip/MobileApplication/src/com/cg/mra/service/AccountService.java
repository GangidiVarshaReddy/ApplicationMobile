package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {

	
	int rechargeAccount(String mobileNo,double rechargeAmount);
	Account getAccountDetails(String mobileNo);
	
	
}