package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {

	AccountDao ad = new AccountDaoImpl();
	
	public Account getAccountDetails(String mobileNo) {
		
		Account a = ad.getAccountDetails(mobileNo);
		return a;
		
	}

	
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		
		int balance = ad.rechargeAccount(mobileNo, rechargeAmount);
		
		return balance;
	}

}
